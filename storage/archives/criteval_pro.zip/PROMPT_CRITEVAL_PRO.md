# 🧠 PROMPT MAÎTRE — CRITEVAL_PRO
### Logiciel Web Professionnel d'Évaluation de Financement de Projets
---

## 📌 CONTEXTE GÉNÉRAL

Tu es un développeur web full-stack senior expert en PHP natif, HTML5, CSS3, JavaScript vanille, jQuery, jQuery UI, Tailwind CSS, et intégrations tierces (PDF, cartographie, emailing, formulaires dynamiques WYSIWYG). Tu dois construire de A à Z une application web professionnelle nommée **Criteval_pro**, un logiciel SaaS d'évaluation de demandes de financement de projets, basé sur un système de critères paramétrables et de notation structurée.

L'application sera d'abord déployée et testée en **local (XAMPP / WAMP / Laragon)** puis hébergée sur un **serveur cPanel Hostinger** en production avec HTTPS activé. Aucun framework PHP (pas de Laravel, Symfony, etc.) — uniquement PHP natif structuré. Aucun TypeScript, Python, React, Dart, Vue ou framework JS lourd.

---

## 🏗️ STACK TECHNIQUE OBLIGATOIRE

| Couche | Technologie |
|---|---|
| Backend | PHP 8.x natif (POO, architecture MVC maison) |
| Base de données | MySQL / MariaDB (PDO, requêtes préparées) |
| Frontend | HTML5, CSS3, Tailwind CSS (via CDN ou build) |
| Interactivité | jQuery 3.x + jQuery UI (drag, resize, sort, datepicker…) |
| Animations | Animate.css + AOS (Animate On Scroll) ou GSAP léger |
| Génération PDF | TCPDF ou FPDF (PHP natif — Best Simple PDF) |
| Cartographie | Leaflet.js + API African Country Library (REST Countries ou equivalent Afrique) |
| Emailing | PHPMailer (SMTP Hostinger + templates HTML) |
| Éditeur WYSIWYG | TinyMCE ou Quill.js (intégration jQuery) |
| Drag & Drop Formulaire | jQuery UI Draggable/Droppable + système de grille canvas personnalisé |
| Graphiques | Chart.js (léger, compatible jQuery) |
| Icônes | Font Awesome 6 Free |
| Calendrier/Planning | FullCalendar.js (version jQuery) |
| Auth OTP / 2FA | PHP custom OTP par email via PHPMailer |
| Sessions & Sécurité | PHP Sessions, CSRF tokens, XSS filtering, bcrypt passwords |

---

## 🎨 IDENTITÉ VISUELLE & DESIGN

### Palette de couleurs
```
--primary       : #1A3C5E   (Bleu marine professionnel — confiance, sérieux)
--secondary     : #2EAF7D   (Vert émeraude — croissance, Afrique, financement)
--accent        : #F5A623   (Or ambré — valeur, excellence, classement)
--danger        : #E74C3C   (Rouge — alertes, suppression)
--neutral-dark  : #1E1E2E   (Fond sombre dashboard)
--neutral-light : #F4F6FA   (Fond clair pages publiques)
--text-main     : #2C3E50
--text-muted    : #7F8C8D
--white         : #FFFFFF
--border        : #DDE1E7
```

### Typographie
- **Titres / Display** : `Poppins` (Bold 700 / SemiBold 600) — Google Fonts
- **Corps / Paragraphes** : `Inter` (Regular 400 / Medium 500) — Google Fonts
- **Données / Tableaux** : `JetBrains Mono` ou `Roboto Mono` (pour notes, scores)

### Principes UI
- Design **card-based**, ombres douces (`box-shadow` étagées), coins arrondis (`border-radius: 12px`)
- Mode sombre natif pour le **dashboard admin** (fond `#1E1E2E`)
- Mode clair pour la **section publique** et les **formulaires candidats**
- Animations d'entrée de pages via **AOS** (fade-up, fade-right) — utilisées avec parcimonie
- Micro-interactions jQuery sur les boutons, les toggles et les cartes
- Totalement **responsive** (mobile-first via Tailwind breakpoints)
- L'**élément signature** : un système de score visuel circulaire animé (SVG + jQuery), utilisé dans les résultats et le dashboard, immédiatement reconnaissable et unique à Criteval_pro.

---

## 📁 ARCHITECTURE DU PROJET

```
criteval_pro/
│
├── index.php                    # Point d'entrée — router maison
├── .htaccess                    # Réécriture d'URL + sécurité
├── config/
│   ├── database.php             # Connexion PDO MySQL
│   ├── config.php               # Constantes globales (APP_NAME, BASE_URL, etc.)
│   ├── mailer.php               # Config PHPMailer SMTP
│   └── auth.php                 # Gestion sessions / rôles
│
├── controllers/
│   ├── HomeController.php
│   ├── AuthController.php
│   ├── AdminController.php
│   ├── ProjectController.php
│   ├── CriteriaController.php
│   ├── FormController.php
│   ├── EvaluationController.php
│   ├── CandidateController.php
│   └── PdfController.php
│
├── models/
│   ├── User.php
│   ├── Project.php
│   ├── Criteria.php
│   ├── Form.php
│   ├── FormField.php
│   ├── Submission.php
│   ├── Evaluation.php
│   └── Ranking.php
│
├── views/
│   ├── layouts/
│   │   ├── public_layout.php    # Layout section publique
│   │   ├── admin_layout.php     # Layout dashboard admin
│   │   └── form_layout.php      # Layout formulaire candidat
│   │
│   ├── public/
│   │   ├── home.php             # Page d'accueil publique
│   │   ├── about.php
│   │   └── contact.php
│   │
│   ├── auth/
│   │   ├── login.php
│   │   ├── otp_verify.php       # Vérification OTP candidat
│   │   └── forgot_password.php
│   │
│   ├── admin/
│   │   ├── dashboard.php        # Module Aperçu
│   │   ├── projects/            # Module Projet (CRUD)
│   │   ├── criteria/            # Module Critères (CRUD)
│   │   ├── forms/               # Module Formulaire (CRUD + Builder)
│   │   │   ├── gallery.php
│   │   │   ├── builder.php      # Éditeur WYSIWYG drag & drop
│   │   │   └── planning.php     # Calendrier de planification
│   │   ├── evaluations/         # Module Évaluation
│   │   │   ├── levels.php
│   │   │   ├── score.php
│   │   │   └── ranking.php
│   │   └── settings/
│   │
│   └── candidate/
│       ├── form_access.php      # Saisie email + OTP
│       └── form_fill.php        # Remplissage formulaire
│
├── assets/
│   ├── css/
│   │   ├── tailwind.css         # Build Tailwind ou CDN
│   │   ├── animate.min.css
│   │   ├── aos.css
│   │   └── custom.css           # Overrides et styles custom
│   ├── js/
│   │   ├── jquery.min.js
│   │   ├── jquery-ui.min.js
│   │   ├── chart.min.js
│   │   ├── fullcalendar.min.js
│   │   ├── leaflet.js
│   │   ├── aos.js
│   │   ├── tinymce/
│   │   ├── app.js               # Scripts globaux
│   │   ├── builder.js           # Logique Form Builder
│   │   ├── dashboard.js         # Graphiques + stats
│   │   └── evaluation.js        # Système de notation
│   ├── img/
│   └── fonts/
│
├── includes/
│   ├── helpers.php              # Fonctions utilitaires globales
│   ├── security.php             # CSRF, XSS, sanitize
│   ├── upload.php               # Gestion uploads fichiers
│   └── otp.php                  # Génération / validation OTP
│
├── pdf_templates/               # Templates TCPDF/FPDF
│   ├── form_export.php
│   ├── evaluation_report.php
│   └── ranking_report.php
│
├── uploads/                     # Médias uploadés (sécurisé)
│   ├── gallery/
│   ├── forms/
│   └── logos/
│
└── database/
    ├── criteval_pro.sql         # Script SQL complet (tables + seed)
    └── migrations/
```

---

## 🗄️ SCHÉMA BASE DE DONNÉES

### Tables principales

```sql
-- Utilisateurs (admins + super-admins)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(191) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('superadmin', 'admin') DEFAULT 'admin',
  is_active TINYINT(1) DEFAULT 1,
  avatar VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Projets
CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  organization VARCHAR(255),
  description TEXT,
  objectives TEXT,
  status ENUM('draft','active','closed','archived') DEFAULT 'draft',
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Galerie projets
CREATE TABLE project_gallery (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  file_path VARCHAR(255),
  caption VARCHAR(255),
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Critères d'évaluation
CREATE TABLE criteria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  label VARCHAR(255) NOT NULL,
  description TEXT,
  weight DECIMAL(5,2) DEFAULT 1.00,
  max_score DECIMAL(5,2) DEFAULT 20.00,
  is_required TINYINT(1) DEFAULT 1,
  order_index INT DEFAULT 0,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Formulaires
CREATE TABLE forms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  project_id INT,
  layout_json LONGTEXT,         -- Structure JSON du builder WYSIWYG
  status ENUM('draft','published','archived') DEFAULT 'draft',
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id),
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Planification formulaires
CREATE TABLE form_schedules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  form_id INT NOT NULL,
  project_id INT,
  access_type ENUM('public_link','email_list','admin_only') DEFAULT 'public_link',
  start_datetime DATETIME,
  end_datetime DATETIME,
  allowed_emails TEXT,          -- JSON array d'emails autorisés
  allowed_countries TEXT,       -- JSON array de codes pays (ISO)
  is_active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
);

-- Soumissions candidats
CREATE TABLE submissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  form_id INT NOT NULL,
  candidate_email VARCHAR(191) NOT NULL,
  candidate_name VARCHAR(150),
  country_code VARCHAR(5),
  data_json LONGTEXT,            -- Réponses du formulaire en JSON
  ip_address VARCHAR(45),
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('pending','under_review','evaluated','published') DEFAULT 'pending',
  FOREIGN KEY (form_id) REFERENCES forms(id)
);

-- OTP candidats
CREATE TABLE otp_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(191) NOT NULL,
  token VARCHAR(10) NOT NULL,
  form_id INT,
  expires_at DATETIME NOT NULL,
  is_used TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Niveaux d'évaluation
CREATE TABLE evaluation_levels (
  id INT AUTO_INCREMENT PRIMARY KEY,
  score_min DECIMAL(5,2),
  score_max DECIMAL(5,2),
  title VARCHAR(100) NOT NULL,
  description TEXT,
  remarks TEXT,
  color_hex VARCHAR(7) DEFAULT '#2EAF7D'
);

-- Évaluations
CREATE TABLE evaluations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  submission_id INT NOT NULL,
  criteria_id INT NOT NULL,
  score DECIMAL(5,2) NOT NULL,
  comment TEXT,
  evaluated_by INT,
  evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE,
  FOREIGN KEY (criteria_id) REFERENCES criteria(id),
  FOREIGN KEY (evaluated_by) REFERENCES users(id)
);

-- Résultats finaux
CREATE TABLE results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  submission_id INT UNIQUE NOT NULL,
  project_id INT NOT NULL,
  total_score DECIMAL(6,2),
  weighted_score DECIMAL(6,2),
  rank_position INT,
  level_id INT,
  is_published TINYINT(1) DEFAULT 0,
  published_at DATETIME,
  FOREIGN KEY (submission_id) REFERENCES submissions(id),
  FOREIGN KEY (project_id) REFERENCES projects(id),
  FOREIGN KEY (level_id) REFERENCES evaluation_levels(id)
);

-- Modules activables/désactivables
CREATE TABLE module_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  module_key VARCHAR(50) UNIQUE NOT NULL,  -- 'apercu','projet','critere','formulaire','evaluation'
  is_enabled TINYINT(1) DEFAULT 1,
  label VARCHAR(100),
  icon VARCHAR(50)
);
```

---

## 🔐 SYSTÈME D'AUTHENTIFICATION & SÉCURITÉ

### Rôles et accès
- **SuperAdmin** : accès total (gestion utilisateurs, modules, paramètres globaux)
- **Admin** : gestion projets, critères, formulaires, évaluations (selon modules activés)
- **Candidat** : accès uniquement au formulaire assigné après authentification OTP

### Flux OTP Candidat
```
1. Candidat arrive sur lien formulaire
2. Saisie de l'email
3. Vérification accès (liste blanche / pays / dates actives)
4. Génération OTP 6 chiffres → envoi email via PHPMailer
5. OTP valide 10 minutes (expiration en base)
6. Après validation OTP → accès formulaire en session sécurisée
7. À la soumission → token session invalidé
```

### Sécurité PHP
- CSRF tokens sur tous les formulaires POST
- Sanitisation XSS (htmlspecialchars, strip_tags)
- Requêtes PDO préparées exclusivement
- Hashage bcrypt pour mots de passe admins
- Rate limiting sur OTP (max 3 tentatives / 15 min)
- .htaccess : interdire accès direct aux dossiers `config/`, `models/`, `includes/`
- Headers de sécurité : `X-Frame-Options`, `Content-Security-Policy`, `X-XSS-Protection`

---

## 🖥️ SECTION 1 — PAGE D'ACCUEIL PUBLIQUE

### Objectif
Présentation professionnelle de Criteval_pro pour les visiteurs, organismes, bailleurs de fonds et candidats africains.

### Structure de la page (défilement vertical)
```
[NAVBAR FIXE]
  Logo Criteval_pro | Menu (Accueil, Avantages, Fonctionnement, Contact) | Bouton "Se Connecter"

[HERO SECTION — Plein écran]
  Titre animé (AOS fade-up) : "L'évaluation de projets, réinventée pour l'Afrique"
  Sous-titre : "Criteval_pro centralise vos appels à projets, structure vos critères et publie vos classements en toute transparence."
  CTA primaire : "Demander une démo" | CTA secondaire : "Voir les fonctionnalités"
  Illustration SVG animée (dashboard abstrait + carte Afrique Leaflet décorative)

[AVANTAGES — 6 cartes icon + texte en grid]
  1. Évaluation structurée par critères paramétrables
  2. Formulaires 100% personnalisables (WYSIWYG)
  3. Notation transparente et traçable
  4. Classements publiés en temps réel
  5. Compatible multi-organisations (Afrique)
  6. Exportation PDF des résultats et rapports

[COMMENT ÇA MARCHE — Timeline horizontale 4 étapes animées]
  Étape 1: Créer le projet + critères
  Étape 2: Publier le formulaire
  Étape 3: Candidats remplissent et soumettent
  Étape 4: Évaluation + Classement publié

[CARTE AFRIQUE INTERACTIVE — Leaflet.js]
  Affichage des pays africains couverts/disponibles
  Tooltip par pays (nom, statut de disponibilité)

[STATISTIQUES ANIMÉES — Compteurs jQuery animés]
  Ex: XX Projets créés | XX Candidatures évaluées | XX Organisations partenaires

[CTA FINAL — Bandeau coloré]
  "Prêt à lancer votre premier appel à projets ?"
  Bouton "Commencer maintenant"

[FOOTER]
  Liens rapides | Contact | Politique de confidentialité | © 2025 Criteval_pro
```

---

## 🛠️ SECTION 2 — DASHBOARD ADMINISTRATION

### Layout Dashboard
```
[SIDEBAR GAUCHE fixe — 260px]
  Logo + Nom app
  Navigation modulaire (icônes + labels) :
    🏠 Aperçu
    📁 Projets
    ✅ Critères
    📋 Formulaires
    🏆 Évaluations
    ⚙️ Paramètres
  Indicateurs de modules ON/OFF (toggle jQuery UI)
  Avatar admin + Déconnexion

[TOPBAR]
  Fil d'ariane | Notifications | Profil admin | Barre de recherche globale

[ZONE CONTENU PRINCIPALE — dynamique par module]
```

---

### 2a. MODULE APERÇU (Dashboard overview)

**Widgets (tous toggleables, déplaçables via jQuery UI Sortable) :**

```
┌─────────────────────────────────────────────────────────────────┐
│  [KPI Card] Projets actifs  │  [KPI Card] Candidatures  │  ...  │
├─────────────────────────────────────────────────────────────────┤
│  [Chart.js] Soumissions par mois (Line chart)                   │
│  [Chart.js] Scores moyens par projet (Bar chart)                │
│  [Chart.js] Répartition par pays (Doughnut + Leaflet map mini)  │
├─────────────────────────────────────────────────────────────────┤
│  [Tableau] Dernières soumissions        │ [Tableau] Top classés │
├─────────────────────────────────────────────────────────────────┤
│  [Calendrier mini] Prochaines échéances formulaires             │
└─────────────────────────────────────────────────────────────────┘
```

**Fonctionnalités :**
- Navigation temporelle (sélecteur de plage de dates jQuery UI Datepicker)
- Filtres : par projet, par organisation, par statut
- Bouton "Exporter tout" → PDF (TCPDF) + CSV (PHP natif)
- Actualisation AJAX automatique (jQuery `$.ajax` polling ou manuel)
- Rappels d'événements (formulaires qui ferment bientôt, évaluations en attente)

---

### 2b. MODULE PROJETS (CRUD complet)

**Liste projets :**
- Vue tableau avec pagination + recherche AJAX
- Filtres : statut, organisation, date
- Badges de statut colorés (Brouillon, Actif, Clôturé, Archivé)
- Actions rapides : Éditer, Dupliquer, Archiver, Supprimer (avec confirmation modale jQuery UI Dialog)

**Formulaire création/édition projet :**
```
Titre *              [Input texte]
Organisation *       [Input texte + autocomplete]
Description          [TinyMCE WYSIWYG — champ riche]
Objectifs/CDC        [TinyMCE WYSIWYG — champ riche]
Statut               [Select : Brouillon / Actif / Clôturé / Archivé]
Galerie              [Uploader images multiples — drag & drop zone jQuery]
                     Aperçu mosaïque des images uploadées
```

**Galerie :**
- Lightbox jQuery pour affichage grande taille
- Réordonnancement par drag & drop (jQuery UI Sortable)
- Suppression individuelle avec confirmation

---

### 2c. MODULE CRITÈRES (CRUD complet)

**Principe :**
- Sélection du projet cible via `<select>` déroulant (un seul projet actif à la fois)
- Interface glissez-déposez pour ordonner les critères (jQuery UI Sortable)

**Formulaire critère :**
```
Projet lié *         [Select déroulant — projets existants]
Libellé critère *    [Input texte]
Description          [Textarea]
Note maximale *      [Input numérique — défaut: 20]
Coefficient/Poids    [Input décimal — défaut: 1.00]
Obligatoire          [Toggle switch jQuery]
Ordre d'affichage    [Géré automatiquement via drag & drop]
```

**Vue liste critères :**
- Tableau réorganisable par drag & drop
- Colonne "Poids total" recalculée dynamiquement (jQuery)
- Aperçu de la pondération en graphique pie (Chart.js temps réel)

---

### 2d. MODULE FORMULAIRES

#### Onglet 1 — GALERIE DE FORMULAIRES

- **Vue mosaïque (tiles/cards)** : chaque formulaire affiché en carte avec titre, projet lié, statut, date, actions
- **Bouton "Ajouter"** : en haut à droite — ouvre le Form Builder
- Actions par carte : Éditer, Dupliquer, Planifier, Aperçu, Exporter PDF, Supprimer

#### Onglet 2 — FORM BUILDER (éditeur WYSIWYG)

**Architecture :**
```
[SIDEBAR GAUCHE — Variables/Composants disponibles]
  Catégories dépliables :
    📝 Texte       : Titre H1/H2, Paragraphe, Étiquette
    🔲 Champs      : Input texte, Email, Téléphone, Numérique, Date, Textarea
    ☑️  Sélection   : Checkbox, Radio, Select, Multi-select
    📎 Médias      : Upload fichier, Upload image, Signature
    📐 Structure   : Section, Séparateur, Grille 2/3/4 colonnes
    🏷️  Info        : Alerte info, Avertissement, Badge

[ZONE DE TRAVAIL CENTRALE — Grille magnétique]
  Canvas avec grille de points (activable/désactivable)
  Effet magnétique snap-to-grid (jQuery UI + logique custom)
  Chaque élément :
    → Déplaçable (jQuery UI Draggable)
    → Redimensionnable (jQuery UI Resizable)
    → Rotatable (handle de rotation custom jQuery)
    → Scalable (handles de coin)
    → Sélectionnable (clic) avec panneau de propriétés activé
    → Multi-sélection possible (Shift+clic ou rectangle de sélection)
    → Groupable/Dégroupable
    → Supprimer (touche Delete ou bouton)
    → Annuler/Rétablir (Ctrl+Z / Ctrl+Y — pile d'actions jQuery)

[PANNEAU DROIT — Propriétés de l'élément sélectionné]
  Géométrie : X, Y, Largeur, Hauteur, Rotation, Scale
  Style : Couleur fond, Couleur bordure, Épaisseur bordure, Coins arrondis
  Typographie : Police, Taille, Gras, Italique, Couleur texte, Alignement
  Validation : Requis, Min/Max, Pattern (regex), Message d'erreur custom
  Logique : Conditionnel (afficher SI champ X = valeur Y)
```

**Toolbar haut du Builder :**
```
[Annuler] [Rétablir] | [Grille ON/OFF] [Magnétisme ON/OFF] | [Aperçu] [Enregistrer brouillon] [Publier]
```

**Rendu final WYSIWYG :**
- Ce que l'admin construit = exactement ce que le candidat voit
- Export PDF du formulaire vide (TCPDF) depuis le builder
- Export PDF du formulaire rempli (depuis une soumission)

#### Onglet 3 — PLANIFICATION

**Calendrier FullCalendar.js :**
- Vue mensuelle / hebdomadaire / liste
- Événements colorés par formulaire
- Clic sur créneau → modal de planification

**Modal de planification :**
```
Formulaire *         [Select — liste formulaires publiés]
Projet associé *     [Select — projets actifs]

QUI peut accéder ?
  ○ Tout le monde (lien public)
  ○ Emails présélectionnés [textarea — liste emails, 1 par ligne]
  ○ Admins uniquement

QUAND ?
  Date/Heure début * [jQuery UI Datetimepicker]
  Date/Heure fin *   [jQuery UI Datetimepicker]

OÙ ? (Pays Afrique éligibles)
  [Selectize.js ou Chosen — multi-select avec API Pays Africains]
  [Case "Tous les pays africains"]

Statut             [Toggle Actif/Inactif]
[Enregistrer]
```

---

### 2e. MODULE ÉVALUATIONS

#### Sous-module A — Niveaux d'évaluation (CRUD)
```
Titre *              [Input texte — ex: "Excellent", "Insuffisant"]
Note minimale *      [Input numérique]
Note maximale *      [Input numérique]
Description          [Textarea]
Remarques            [Textarea]
Couleur de niveau    [Color picker jQuery UI]
```

#### Sous-module B — Notation des soumissions

**Workflow :**
```
1. Sélectionner un projet [Select]
2. Liste des soumissions en attente d'évaluation (tableau paginé)
3. Clic sur "Évaluer" → page d'évaluation d'une soumission
```

**Page d'évaluation d'une soumission :**
```
[Colonne gauche] Réponses du candidat (lecture seule — formulaire rempli)
[Colonne droite] Critères du projet + champs de notation

Pour chaque critère :
  - Libellé du critère
  - Note /[max_score]   [Input jQuery UI Slider + valeur numérique synchronisée]
  - Commentaire         [Textarea]
  - Indicateur visuel de la pondération

[Score final calculé dynamiquement en temps réel — jQuery]
[Indicateur circulaire SVG animé — élément signature Criteval_pro]
[Bouton "Enregistrer évaluation"]
```

#### Sous-module C — Classements

**Tableau de classement par projet :**
- Tri automatique par score pondéré décroissant
- Rang affiché avec médailles 🥇🥈🥉 pour top 3
- Historique des classements dans le temps (Chart.js évolution de rang)
- Filtres : par date d'évaluation, par niveau
- Actions : **Publier/Dépublier résultat** par candidat ou en masse
- Export PDF du classement complet (TCPDF — rapport officiel mis en page)
- Export CSV

---

## 📄 SECTION 3 — FORMULAIRE CANDIDAT

### Flux d'accès
```
URL unique du formulaire (ex: /formulaire/{token_unique})
  ↓
[Page d'accueil formulaire]
  - Logo Criteval_pro + Titre du projet
  - Description de l'appel à candidature
  - Champ email *
  - Bouton "Recevoir mon code d'accès"
  ↓
[Vérification accès (PHP)]
  - Formulaire actif ? (date + heure)
  - Pays de l'IP autorisé ?
  - Email dans liste blanche (si restreint) ?
  ↓
[Page OTP]
  - "Un code à 6 chiffres a été envoyé à {email}"
  - 6 inputs séparés (auto-focus suivant jQuery)
  - Timer compte à rebours 10 minutes (jQuery)
  - Lien "Renvoyer le code" (après 60s)
  ↓
[Formulaire de remplissage]
  - Rendu exact du WYSIWYG builder
  - Sauvegarde automatique toutes les 2 minutes (localStorage + AJAX)
  - Barre de progression (% complété jQuery)
  - Validation côté client (jQuery Validation Plugin) + côté serveur (PHP)
  - Upload de pièces jointes si champs présents
  - Bouton "Soumettre ma candidature"
  ↓
[Page de confirmation]
  - Numéro de référence unique de la soumission
  - Option de télécharger son formulaire rempli (PDF TCPDF)
  - Email de confirmation automatique (PHPMailer)
```

---

## 📧 SYSTÈME D'EMAILING

### Templates emails (HTML responsive, PHPMailer)

| Événement | Destinataire | Template |
|---|---|---|
| OTP code d'accès | Candidat | `otp_email.php` |
| Confirmation soumission | Candidat | `submission_confirm.php` |
| Résultat publié | Candidat | `result_published.php` |
| Nouvelle soumission reçue | Admin(s) | `admin_new_submission.php` |
| Rappel fermeture formulaire | Admin | `form_closing_reminder.php` |
| Création compte admin | Admin | `welcome_admin.php` |

### Configuration SMTP (config/mailer.php)
```php
define('SMTP_HOST',     'smtp.hostinger.com');
define('SMTP_USER',     'noreply@votredomaine.com');
define('SMTP_PASS',     'VOTRE_MOT_DE_PASSE');
define('SMTP_PORT',     587);
define('SMTP_SECURE',   'tls');
define('MAIL_FROM',     'noreply@votredomaine.com');
define('MAIL_FROM_NAME','Criteval Pro');
```

---

## 🗺️ INTÉGRATION API PAYS AFRICAINS

### Source
- **REST Countries API** filtré Afrique : `https://restcountries.com/v3.1/region/africa`
- OU **API africaine dédiée** (African Countries API) — préférer source avec données en français

### Utilisation dans l'app
```javascript
// Chargement asynchrone jQuery (mis en cache localStorage 24h)
function loadAfricanCountries() {
  const cached = localStorage.getItem('african_countries');
  const cacheTime = localStorage.getItem('african_countries_time');
  const now = Date.now();

  if (cached && cacheTime && (now - cacheTime) < 86400000) {
    return Promise.resolve(JSON.parse(cached));
  }

  return $.getJSON('https://restcountries.com/v3.1/region/africa')
    .then(data => {
      const countries = data.map(c => ({
        code: c.cca2,
        name: c.translations?.fra?.common || c.name.common,
        flag: c.flags?.svg,
        latlng: c.latlng
      })).sort((a,b) => a.name.localeCompare(b.name, 'fr'));
      localStorage.setItem('african_countries', JSON.stringify(countries));
      localStorage.setItem('african_countries_time', now);
      return countries;
    });
}
```

### Utilisation Leaflet.js
- Carte d'accueil publique : pays africains mis en évidence, tooltip par pays
- Carte dans le planning formulaires : visualisation zones ciblées
- Carte dans le dashboard : répartition géographique des soumissions (choroplèth via GeoJSON Afrique)

---

## 📑 GÉNÉRATION PDF (TCPDF / FPDF)

### Types de documents générés

1. **Formulaire vide (gabarit)** — à imprimer/distribuer
2. **Formulaire rempli d'un candidat** — fidèle au WYSIWYG
3. **Rapport d'évaluation individuel** — score par critère + score final + niveau
4. **Rapport de classement complet** — tous les candidats d'un projet classés
5. **Export données dashboard** — résumé statistique avec graphiques (Chart.js → image via `html2canvas` + intégration TCPDF)

### En-têtes PDF standards
- Logo Criteval_pro + nom de l'organisation
- Titre du document + référence unique
- Date et heure de génération
- Pied de page : pagination + "Document généré par Criteval_pro"

---

## ⚙️ PARAMÈTRES ADMINISTRATION

```
[Informations générales]
  - Nom de l'application (configurable)
  - Logo (upload)
  - Adresse / Contact / Site web

[Gestion modules]
  - Toggle ON/OFF par module (Aperçu, Projets, Critères, Formulaires, Évaluations)
  - Chaque désactivation masque le module dans la sidebar et redirige

[Gestion utilisateurs admin]
  - CRUD complet (SuperAdmin uniquement)
  - Assignation de rôle

[Paramètres email]
  - Test SMTP en live
  - Personnalisation du footer email

[Sécurité]
  - Durée de vie session (minutes)
  - Max tentatives OTP
  - Activation/désactivation logs d'accès
```

---

## 🔄 INTERACTIONS JQUERY — COMPORTEMENTS ATTENDUS

```javascript
// 1. Sidebar toggleable (mobile + desktop)
$('#sidebarToggle').on('click', function() {
  $('#sidebar').toggleClass('collapsed');
  $('#mainContent').toggleClass('sidebar-collapsed');
});

// 2. Modules drag & drop dans le dashboard Aperçu
$('#widgetContainer').sortable({
  handle: '.widget-handle',
  animation: 150,
  update: function() { saveWidgetOrder(); }
});

// 3. Confirmations de suppression
$('.btn-delete').on('click', function(e) {
  e.preventDefault();
  const url = $(this).data('url');
  $('<div>').text('Confirmer la suppression ?').dialog({
    buttons: {
      'Supprimer': function() { window.location = url; },
      'Annuler': function() { $(this).dialog('close'); }
    }
  });
});

// 4. Sliders de notation synchronisés
$('.score-slider').each(function() {
  const input = $(this).siblings('.score-input');
  $(this).slider({
    min: 0, max: parseFloat($(this).data('max')),
    step: 0.5,
    slide: function(e, ui) {
      input.val(ui.value);
      updateFinalScore();
    }
  });
});

// 5. Auto-save formulaire candidat
setInterval(function() {
  if ($('#candidateForm').length) {
    const data = $('#candidateForm').serialize();
    $.post('/api/autosave', { data: data, ref: FORM_REF }, function(res) {
      $('#autosave-status').text('Sauvegardé à ' + new Date().toLocaleTimeString());
    });
  }
}, 120000);
```

---

## 🚀 DÉPLOIEMENT

### Local (développement)
```
Serveur : XAMPP / Laragon (PHP 8.x + MySQL 8.x)
URL     : http://localhost/criteval_pro/
Config  : config/config.php → APP_ENV = 'development'
```

### Production (Hostinger cPanel)
```
PHP     : 8.1+ (via cPanel PHP Selector)
MySQL   : Créer base via phpMyAdmin + importer criteval_pro.sql
Dossier : public_html/criteval_pro/ OU sous-domaine criteval.votredomaine.com
HTTPS   : Certificat SSL Let's Encrypt (1-clic Hostinger)
.env    : Variables sensibles hors du dépôt Git
Cron    : Tâche cron Hostinger → rappels formulaires fermants (daily 08:00)
```

### Sécurité .htaccess (racine)
```apache
Options -Indexes
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?url=$1 [QSA,L]

# Bloquer accès direct aux dossiers sensibles
RewriteRule ^(config|models|includes|database)/ - [F,L]

# Headers sécurité
Header set X-Frame-Options "SAMEORIGIN"
Header set X-Content-Type-Options "nosniff"
Header set X-XSS-Protection "1; mode=block"
```

---

## 📋 ORDRE DE DÉVELOPPEMENT RECOMMANDÉ

```
Phase 1 — Fondations (Semaine 1-2)
  ✅ Structure dossiers + config + router PHP
  ✅ Base de données SQL complète
  ✅ Auth admin (login, sessions, rôles)
  ✅ Layout admin + sidebar + topbar

Phase 2 — Modules core (Semaine 3-5)
  ✅ Module Projets (CRUD complet + galerie)
  ✅ Module Critères (CRUD + pondération)
  ✅ Module Niveaux d'évaluation

Phase 3 — Form Builder (Semaine 6-8)
  ✅ Galerie formulaires
  ✅ Form Builder WYSIWYG (drag & drop jQuery UI)
  ✅ Planification FullCalendar

Phase 4 — Candidats (Semaine 9-10)
  ✅ Flux OTP + accès formulaire
  ✅ Rendu formulaire candidat
  ✅ Soumission + confirmation email

Phase 5 — Évaluation (Semaine 11-12)
  ✅ Interface de notation par critères
  ✅ Calcul score pondéré
  ✅ Classements + publication

Phase 6 — Dashboard + PDF (Semaine 13-14)
  ✅ Module Aperçu (graphiques Chart.js)
  ✅ Exports PDF (TCPDF — tous types)
  ✅ Exports CSV

Phase 7 — Page publique + finitions (Semaine 15-16)
  ✅ Page d'accueil publique complète
  ✅ Carte Leaflet Afrique
  ✅ Paramètres admin
  ✅ Tests complets + corrections
  ✅ Déploiement Hostinger
```

---

## ✅ CHECKLIST DE QUALITÉ FINALE

Avant livraison, vérifier :
- [ ] Application 100% responsive (mobile, tablette, desktop)
- [ ] Tous les formulaires protégés CSRF
- [ ] Aucune requête SQL sans PDO préparé
- [ ] PDF générés correctement (tous les types)
- [ ] Emails reçus (OTP, confirmation, résultat)
- [ ] Form Builder sauvegarde et restitue fidèlement le layout
- [ ] Classements recalculés automatiquement à chaque nouvelle évaluation
- [ ] Modules activables/désactivables fonctionnels
- [ ] Export CSV Dashboard fonctionne
- [ ] Carte Leaflet chargée et interactive
- [ ] API pays africains chargée et mise en cache
- [ ] .htaccess en place (réécriture + protection dossiers)
- [ ] SSL activé en production Hostinger
- [ ] Aucun `var_dump`, `echo`, ou `die` de debug en production

---

*Prompt rédigé pour Criteval_pro — Version 1.0 — Développement local puis déploiement cPanel Hostinger*
*Stack: PHP 8.x natif | MySQL | jQuery | jQuery UI | Tailwind CSS | Chart.js | Leaflet.js | TCPDF | PHPMailer | FullCalendar | TinyMCE | AOS | Animate.css*
